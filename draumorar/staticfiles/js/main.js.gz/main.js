// $(document).ready(function() {
//     $(window).scroll(function() {
//         if ($(this).scrollTop() > 1) {
//             $(".parallax").css({"opacity": "0.3"})
//         }
//         else {
//             $(".parallax").css({"opacity": "1"})
//         }
//     })
// })

